# Project Development

## Suggested Flow Steps

1. Open ServiceNow Flow Designer.
2. Create a new flow.
3. Configure the Incident trigger.
4. Add classification logic using conditions.
5. Map ticket information to categories/subcategories.
6. Configure assignment group routing.
7. Add an Update Record action.
8. Save, test, and activate the flow.

## Example Classification Rules

| Ticket Information | Classification | Assignment |
|---|---|---|
| Password/login issue | Access / Authentication | Service Desk |
| Laptop/desktop issue | Hardware | Hardware Support |
| Application failure | Software / Application | Application Support |
| Network/connectivity issue | Network | Network Support |
