# Requirement Analysis

## Functional Requirements
1. Detect newly created or updated incidents.
2. Read relevant incident fields.
3. Evaluate classification conditions.
4. Set category/subcategory.
5. Select the appropriate assignment group.
6. Update the incident automatically.
7. Maintain a traceable flow execution.

## Non-Functional Requirements
- Reliable execution
- Easy maintenance
- Clear decision logic
- Secure access to incident data
- Minimal manual intervention
