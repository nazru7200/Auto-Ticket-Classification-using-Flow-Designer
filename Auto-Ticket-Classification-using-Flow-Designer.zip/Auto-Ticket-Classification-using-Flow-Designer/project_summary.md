# Auto Ticket Classification using Flow Designer

## Repository Structure

1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design Phase
4. Project Planning
5. Project Development
6. Project Testing
7. Project Documentation
8. Project Demonstration

## Project Title
**Auto Ticket Classification using Flow Designer**

## Project Overview
This project automates IT ticket classification using ServiceNow Flow Designer. Incoming incidents are analyzed based on ticket information such as category, description, keywords, and priority-related details. The flow then assigns an appropriate classification, category/subcategory, assignment group, and other routing information.

## Suggested Technology
- ServiceNow
- Flow Designer
- Incident Management
- Business Rules / Data Policies where required
- Optional: IntegrationHub or AI/ML classification

## Objective
Reduce manual ticket classification and improve consistent routing of incidents to the appropriate support team.

## Expected Outcome
A Flow Designer automation that receives or updates an incident and automatically classifies and routes it according to predefined rules.
