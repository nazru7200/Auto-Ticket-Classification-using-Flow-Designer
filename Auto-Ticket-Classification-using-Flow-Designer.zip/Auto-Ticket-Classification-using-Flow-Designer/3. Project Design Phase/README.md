# Project Design Phase

## High-Level Flow

Incident Created/Updated
        ↓
Flow Designer Trigger
        ↓
Read Incident Details
        ↓
Classification Conditions
        ↓
Set Category/Subcategory
        ↓
Set Assignment Group
        ↓
Update Incident
        ↓
Log / Verify Result

## Main Components
- Trigger
- Flow actions
- If/Else or Decision logic
- Record Update
- Optional notification
