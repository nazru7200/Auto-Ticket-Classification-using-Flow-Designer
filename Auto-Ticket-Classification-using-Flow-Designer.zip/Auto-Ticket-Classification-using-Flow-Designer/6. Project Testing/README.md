# Project Testing

## Test Cases

| Test | Input | Expected Result |
|---|---|---|
| TC01 | Password reset request | Access classification |
| TC02 | Laptop not working | Hardware classification |
| TC03 | Application error | Software classification |
| TC04 | Network unavailable | Network classification |
| TC05 | Unknown description | Default/manual review path |

## Testing Checklist
- Trigger executes correctly
- Conditions select the expected branch
- Incident fields update correctly
- Assignment group is correct
- No unintended records are modified
- Flow remains inactive until testing is complete
