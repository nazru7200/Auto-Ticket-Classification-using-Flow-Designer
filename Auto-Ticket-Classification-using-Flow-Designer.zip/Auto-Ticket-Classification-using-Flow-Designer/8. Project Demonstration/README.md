# Project Demonstration

## Demonstration Sequence

1. Show the Incident table.
2. Create a sample incident.
3. Enter a ticket description.
4. Show the Flow Designer trigger.
5. Demonstrate the classification decision.
6. Show automatic category/subcategory update.
7. Show assignment group update.
8. Display the final classified ticket.
9. Show the flow execution details.

## Demo Evidence
Add screenshots or screen recordings of:
- Flow Designer canvas
- Trigger configuration
- Decision conditions
- Update Record action
- Final classified incident
